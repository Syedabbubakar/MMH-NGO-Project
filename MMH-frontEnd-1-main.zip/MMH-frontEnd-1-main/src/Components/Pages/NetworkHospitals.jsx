import React from 'react'

const NetworkHospitals = () => {
  return (
    <div>NetworkHospitals</div>
  )
}

export default NetworkHospitals